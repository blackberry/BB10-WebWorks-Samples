function downloadFile() {
    document.location.href = "local:///fileDownload.html";
}

function uploadFile() {
    //document.location.href = "local:///fileUpload.html";
}

function xhrFile() {
    //document.location.href = "local:///xhr2.html";
}

function fsAPITest() {
    //document.location.href = "local:///fileSystem.html";
}
